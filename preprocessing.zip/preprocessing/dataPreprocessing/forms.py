# coding=utf8
from django import forms

class NulosNumericosForm(forms.Form):
    CHOICES = (
        (0, '0'),
        ('Media', 'Media'),
    )
    completingValue = forms.ChoiceField(choices = CHOICES, widget=forms.RadioSelect)

class NulosCategoricosForm(forms.Form):
    CHOICES = (
        ("", 'Cadena vacía'),
        ('Moda', 'Moda'),
    )
    completingValue = forms.ChoiceField(choices = CHOICES, widget=forms.RadioSelect)

class AnomalosNumericosForm(forms.Form):
    CHOICES = (
        (0, '0'),
        ('NULL', 'Valor nulo'),
        ('Media', 'Media'),
    )
    replacingValue = forms.ChoiceField(choices = CHOICES, widget=forms.RadioSelect)

class AnomalosCategoricosForm(forms.Form):
    CHOICES = (
        ("", 'Cadena vacía'),
        ('NULL', 'Valor nulo'),
        ('Moda', 'Moda'),
    )
    replacingValue = forms.ChoiceField(choices = CHOICES, widget=forms.RadioSelect)
