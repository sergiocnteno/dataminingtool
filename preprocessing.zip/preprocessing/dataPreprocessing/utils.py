import math

def getOne(array):
    for i in array:
        return i

def get_1D_array(column):
    array1D = []
    for i in column:
        for j in i:
            array1D.append(j)
    return array1D

def stddeviation(array, meanValue):
    addition = 0
    for i in array:
        addition += math.pow(i - meanValue, 2)
    variance = addition / len(array)
    return math.sqrt(variance)

def mean(array):
    addition = 0
    for i in array:
        addition += i
    return addition / len(array)
