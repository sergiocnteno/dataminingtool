import math
from django.shortcuts import render, get_object_or_404, redirect
from django.db import connection
from dataPreprocessing.utils import getOne, get_1D_array, stddeviation, mean
from collections import Counter
from .forms import NulosNumericosForm, NulosCategoricosForm, AnomalosNumericosForm, AnomalosCategoricosForm

# Create your views here.

from .models import Proyecto

def index(request, nombreProyecto):
	proyecto = get_object_or_404(Proyecto, pk=nombreProyecto)
	with connection.cursor() as cursor:
		cursor.execute("SELECT column_name, data_type FROM information_schema.columns WHERE table_schema=%s AND table_name=%s", [proyecto.nombreProyecto, proyecto.nombreProyecto])
		consultasSQL = cursor.fetchall()
		cursor.execute("USE " + proyecto.nombreProyecto)
		datosTabla = []
		for registro in consultasSQL:
			temp = []
			temp.append(registro[0])
			temp.append(registro[1])
			cursor.execute("SELECT COUNT(" + registro[0] + " is not null) FROM " + proyecto.nombreProyecto + " WHERE " + registro[0] + " is not null")
			temp.append(getOne(cursor.fetchone()))
			cursor.execute("SELECT COUNT(" + registro[0] + " is null) FROM " + proyecto.nombreProyecto + " WHERE " + registro[0] + " is null")
			temp.append(getOne(cursor.fetchone()))
			cursor.execute("SELECT COUNT(DISTINCT " + registro[0] + ") FROM " + proyecto.nombreProyecto)
			temp.append(getOne(cursor.fetchone()))
			datosTabla.append(temp)
	cursor.close()

	context = {
		'proyecto': proyecto,
		'datosTabla': datosTabla,
		}

	return render(request, 'dataPreprocessing/index.html', context)

def faltantes(request, nombreProyecto, nombreAtributo):
	proyecto = get_object_or_404(Proyecto, pk=nombreProyecto)
	with connection.cursor() as cursor:
		cursor.execute("SELECT data_type FROM information_schema.columns WHERE table_schema=%s AND table_name=%s AND column_name=%s", [proyecto.nombreProyecto, proyecto.nombreProyecto, nombreAtributo])
		tipo = getOne(cursor.fetchone())

		if tipo == "float":
			cursor.execute("USE " + proyecto.nombreProyecto)
			cursor.execute("SELECT AVG(" + nombreAtributo + ") FROM " + proyecto.nombreProyecto)
			media = getOne(cursor.fetchone())
			if request.method == 'POST':
				form = NulosNumericosForm(request.POST)
				if form.is_valid():
					valorCompletar = form.cleaned_data['completingValue']
					if valorCompletar == "Media":
						cursor.execute("UPDATE " + proyecto.nombreProyecto + " SET " + nombreAtributo + "=%s WHERE " + nombreAtributo + " is null", [media])
					else:
						cursor.execute("UPDATE " + proyecto.nombreProyecto + " SET " + nombreAtributo + "=%s WHERE " + nombreAtributo + " is null", [valorCompletar])
					cursor.close()
					return redirect('dataPreprocessing:index', proyecto.nombreProyecto)
			else:
				form = NulosNumericosForm()

		elif tipo == "varchar":
			#Sustituir por moda
			cursor.execute("USE " + proyecto.nombreProyecto)
			cursor.execute("SELECT " + nombreAtributo + " FROM " + proyecto.nombreProyecto)
			valores = get_1D_array(cursor.fetchall())
			moda = Counter(valores).most_common(1)[0][0]
			if request.method == "POST":
				form = NulosCategoricosForm(request.POST)
				if form.is_valid():
					valorCompletar = form.cleaned_data['completingValue']
					if valorCompletar == "Moda":
						cursor.execute("UPDATE " + proyecto.nombreProyecto + " SET " + nombreAtributo + "=%s WHERE " + nombreAtributo + " is null", [moda])
					else:
						cursor.execute("UPDATE " + proyecto.nombreProyecto + " SET " + nombreAtributo + "=%s WHERE " + nombreAtributo + " is null", [valorCompletar])
					cursor.close()
					return redirect('dataPreprocessing:index', proyecto.nombreProyecto)
			else:
				form = NulosCategoricosForm()

	context = {
		'proyecto': proyecto,
		'nombreAtributo': nombreAtributo,
		'form': form,
	}
	cursor.close()
	return render(request, 'dataPreprocessing/faltantes.html', context)

def anomalos(request, nombreProyecto, nombreAtributo):
	proyecto = get_object_or_404(Proyecto, pk=nombreProyecto)
	with connection.cursor() as cursor:
		cursor.execute("SELECT data_type FROM information_schema.columns WHERE table_schema=%s AND table_name=%s AND column_name=%s", [proyecto.nombreProyecto, proyecto.nombreProyecto, nombreAtributo])
		tipo = getOne(cursor.fetchone())

		if tipo == "float":
			cursor.execute("USE " + proyecto.nombreProyecto)
			cursor.execute("SELECT AVG(" + nombreAtributo + ") FROM " + proyecto.nombreProyecto)
			media = getOne(cursor.fetchone())
			cursor.execute("SELECT DISTINCT " + nombreAtributo + " FROM " + proyecto.nombreProyecto + " WHERE " + nombreAtributo + " is not null")
			valoresAtributo = get_1D_array(cursor.fetchall())
			rango = 3 * stddeviation(valoresAtributo, media)
			valoresAnomalos = []
			for valor in valoresAtributo:
				if math.fabs(valor - media) > rango:
					valoresAnomalos.append(valor)
			if request.method == 'POST':
				form = AnomalosNumericosForm(request.POST)
				if form.is_valid():
					valorCorregir = form.cleaned_data['replacingValue']
					if valorCorregir == "Media":
						for i in valoresAnomalos:
							cursor.execute("UPDATE " + proyecto.nombreProyecto + " SET " + nombreAtributo + "=%s WHERE " + nombreAtributo + "=%s", [media, i])
					elif valorCorregir == "NULL":
						for i in valoresAnomalos:
							cursor.execute("UPDATE " + proyecto.nombreProyecto + " SET " + nombreAtributo + "=NULL WHERE " + nombreAtributo + "=%s", [i])
					else:
						for i in valoresAnomalos:
							cursor.execute("UPDATE " + proyecto.nombreProyecto + " SET " + nombreAtributo + "=%s WHERE " + nombreAtributo + "=%s", [valorCorregir, i])
					cursor.close()
					return redirect('dataPreprocessing:index', proyecto.nombreProyecto)
			else:
				form = AnomalosNumericosForm()

		elif tipo == "varchar":
			cursor.execute("USE " + proyecto.nombreProyecto)
			cursor.execute("SELECT " + nombreAtributo + " FROM " + nombreProyecto + " WHERE " + nombreAtributo + " is not null")
			valoresAtributo = get_1D_array(cursor.fetchall())
			moda = Counter(valoresAtributo).most_common(1)[0][0]
			frecuencias = []
			for valor in valoresAtributo:
				cursor.execute("SELECT COUNT(" + nombreAtributo + ") FROM " + proyecto.nombreProyecto + " WHERE " + nombreAtributo + "=%s", [valor])
				frecuencias.append(getOne(cursor.fetchone()))
			media = mean(frecuencias)
			rango = 3 * stddeviation(frecuencias, media)
			print rango
			valoresAnomalos = []
			for i in zip(valoresAtributo, frecuencias):
				if math.fabs(i[1] - media) > rango:
					valoresAnomalos.append(i[0])
			if request.method == 'POST':
				form = AnomalosCategoricosForm(request.POST)
				if form.is_valid():
					valorCorregir = form.cleaned_data['replacingValue']
					if valorCorregir == "Moda":
						for i in valoresAnomalos:
							cursor.execute("UPDATE " + proyecto.nombreProyecto + " SET " + nombreAtributo + "=%s WHERE " + nombreAtributo + "=%s", [moda, i])
					elif valorCorregir == "NULL":
						for i in valoresAnomalos:
							cursor.execute("UPDATE " + proyecto.nombreProyecto + " SET " + nombreAtributo + "=NULL WHERE " + nombreAtributo + "=%s", [i])
					else:
						for i in valoresAnomalos:
							cursor.execute("UPDATE " + proyecto.nombreProyecto + " SET " + nombreAtributo + "=%s WHERE " + nombreAtributo + "=%s", [valorCorregir, i])
					cursor.close()
					return redirect('dataPreprocessing:index', proyecto.nombreProyecto)
			else:
				form = AnomalosCategoricosForm()

	context = {
		'proyecto': proyecto,
		'nombreAtributo': nombreAtributo,
		'form': form,
		'valoresAnomalos': valoresAnomalos,
	}
	cursor.close()
	return render(request, 'dataPreprocessing/anomalos.html', context)
