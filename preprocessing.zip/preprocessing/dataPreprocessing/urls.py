from django.conf.urls import url

from . import views

app_name = 'dataPreprocessing'
urlpatterns = [
	url(r'^(?P<nombreProyecto>[a-zA-Z]+[0-9a-zA-Z]*)/tratamiento/$', views.index, name='index'),
	url(r'^(?P<nombreProyecto>[a-zA-Z]+[0-9a-zA-Z]*)/faltantes/(?P<nombreAtributo>[a-zA-Z]+[0-9a-zA-Z]*)/$', views.faltantes, name='faltantes'),
	url(r'^(?P<nombreProyecto>[a-zA-Z]+[0-9a-zA-Z]*)/anomalos/(?P<nombreAtributo>[a-zA-Z]+[0-9a-zA-Z]*)/$', views.anomalos, name='anomalos')
]
